const fs = require('node:fs');
const path = require('node:path');

const repoPath = process.env.GITHUB_REPOSITORY || '';
const tag = process.env.GITHUB_REF_NAME || '';
const parts = repoPath.split('/');
if (parts.length !== 2 || !parts[0] || !parts[1]) {
  throw new Error('GITHUB_REPOSITORY must be set to owner/repository by the release workflow.');
}
const owner = parts[0];
const repo = parts[1];
const version = tag.replace(/^v/, '');
if (!/^\d+\.\d+\.\d+$/.test(version)) {
  throw new Error(`Stable release tag must look like v1.2.3; received: ${tag || '(empty)'}`);
}

const packagePath = path.join(__dirname, 'package.json');
const packageJson = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
packageJson.version = version;
packageJson.build = packageJson.build || {};
packageJson.build.publish = [{ provider: 'github', owner, repo, releaseType: 'release' }];
fs.writeFileSync(packagePath, JSON.stringify(packageJson, null, 2) + '\n');

const lockPath = path.join(__dirname, 'package-lock.json');
const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
lock.version = version;
if (lock.packages && lock.packages['']) lock.packages[''].version = version;
fs.writeFileSync(lockPath, JSON.stringify(lock, null, 2) + '\n');

const updateConfigPath = path.join(__dirname, 'update-config.json');
fs.writeFileSync(updateConfigPath, JSON.stringify({ configured: true, provider: 'github', owner, repo }, null, 2) + '\n');
console.log(`Configured Deckize ${version} updates from public GitHub Releases: ${owner}/${repo}`);
