const fs = require('node:fs');
const path = require('node:path');

const outputDir = path.resolve(__dirname, '..', 'downloads', '_build');
const source = path.join(outputDir, 'Deckize-Windows-Setup.exe');
const destDir = path.resolve(__dirname, '..', 'downloads');
const target = path.join(destDir, 'Deckize-Windows-Setup.exe');

if(!fs.existsSync(source)) throw new Error(`Windows installer was not produced: ${source}`);
const size = fs.statSync(source).size;
if(size < 1024 * 1024) throw new Error(`Installer looks unexpectedly small (${size} bytes)`);
fs.mkdirSync(destDir, { recursive: true });
fs.copyFileSync(source, target);
fs.rmSync(outputDir, { recursive: true, force: true });
console.log(`Created ${target} (${(size / (1024 * 1024)).toFixed(1)} MiB)`);
