const { app, BrowserWindow, shell, ipcMain } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const { autoUpdater } = require('electron-updater');

app.setAppUserModelId('com.deckize.presentation');

let mainWindow;
let updateConfig = { configured: false, provider: 'github', owner: '', repo: '' };
try {
  updateConfig = Object.assign(updateConfig, JSON.parse(fs.readFileSync(path.join(__dirname, 'update-config.json'), 'utf8')));
} catch (error) {
  // A missing config is expected for local development builds.
}

let updateState = {
  state: 'idle',
  currentVersion: app.getVersion(),
  configured: !!updateConfig.configured
};

function sendUpdateState(state, extra = {}) {
  updateState = Object.assign({
    state,
    currentVersion: app.getVersion(),
    configured: !!updateConfig.configured
  }, extra);
  if (mainWindow && !mainWindow.isDestroyed() && !mainWindow.webContents.isDestroyed()) {
    mainWindow.webContents.send('deckize:update:status', updateState);
  }
  return updateState;
}

function friendlyUpdateError(error) {
  const detail = String(error && (error.message || error) || '').toLowerCase();
  if (/404|not found|latest\.yml/.test(detail)) return 'No published update was found. Try again after a release is published.';
  if (/enotfound|econn|network|timeout|internet/.test(detail)) return 'Could not reach the update service. Check your internet connection.';
  return 'Could not check for updates. Try again later.';
}

// Deliberate manual checks: Deckize never contacts the release service unless the
// user presses “Check for updates” in the desktop Settings sheet.
autoUpdater.autoDownload = false;
autoUpdater.autoInstallOnAppQuit = false;
autoUpdater.allowPrerelease = false;

autoUpdater.on('checking-for-update', () => sendUpdateState('checking'));
autoUpdater.on('update-available', info => sendUpdateState('available', {
  version: info && info.version ? info.version : '',
  releaseDate: info && info.releaseDate ? info.releaseDate : ''
}));
autoUpdater.on('update-not-available', info => sendUpdateState('up-to-date', {
  currentVersion: info && info.version ? info.version : app.getVersion()
}));
autoUpdater.on('download-progress', progress => sendUpdateState('downloading', {
  percent: Math.max(0, Math.min(100, Math.round(Number(progress && progress.percent) || 0)))
}));
autoUpdater.on('update-downloaded', info => sendUpdateState('downloaded', {
  version: info && info.version ? info.version : ''
}));
autoUpdater.on('error', error => sendUpdateState('error', {
  message: friendlyUpdateError(error)
}));

ipcMain.handle('deckize:update:version', () => app.getVersion());
ipcMain.handle('deckize:update:status', () => {
  if (!app.isPackaged || !updateConfig.configured) {
    return Object.assign({}, updateState, {
      state: 'not-configured',
      configured: false,
      message: 'Update checks become available after the first GitHub release is published.'
    });
  }
  return updateState;
});
ipcMain.handle('deckize:update:check', async () => {
  if (!app.isPackaged || !updateConfig.configured || !updateConfig.owner || !updateConfig.repo) {
    return sendUpdateState('not-configured', {
      configured: false,
      message: 'Update checks become available after the first GitHub release is published.'
    });
  }
  if (updateState.state === 'checking' || updateState.state === 'downloading') return updateState;
  sendUpdateState('checking');
  try {
    await autoUpdater.checkForUpdates();
    return updateState;
  } catch (error) {
    return sendUpdateState('error', { message: friendlyUpdateError(error) });
  }
});
ipcMain.handle('deckize:update:download', async () => {
  if (updateState.state !== 'available') return updateState;
  sendUpdateState('downloading', { percent: 0 });
  try {
    await autoUpdater.downloadUpdate();
    return updateState;
  } catch (error) {
    return sendUpdateState('error', { message: friendlyUpdateError(error) });
  }
});
ipcMain.handle('deckize:update:install', () => {
  if (updateState.state !== 'downloaded') return updateState;
  autoUpdater.quitAndInstall(false, true);
  return updateState;
});

function createWindow(){
  mainWindow = new BrowserWindow({
    width: 1360,
    height: 900,
    minWidth: 360,
    minHeight: 560,
    show: false,
    autoHideMenuBar: true,
    title: 'Deckize',
    backgroundColor: '#f8fafd',
    icon: path.join(__dirname, 'assets', process.platform === 'darwin' ? 'deckize-mac-icon-source.png' : 'deckize.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if(/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.loadFile(path.join(__dirname, 'index.html'), {
    query: { deckizeDesktop: '1' }
  });
  mainWindow.on('closed', () => { mainWindow = null; });
}

app.whenReady().then(createWindow);
app.on('activate', () => {
  if(BrowserWindow.getAllWindows().length === 0) createWindow();
});
app.on('window-all-closed', () => {
  if(process.platform !== 'darwin') app.quit();
});
