const fs = require('node:fs');
const path = require('node:path');

const source = path.resolve(__dirname, '..', 'index.html');
const target = path.join(__dirname, 'index.html');
if(!fs.existsSync(source)) throw new Error(`Deckize web app not found: ${source}`);
fs.copyFileSync(source, target);
console.log(`Prepared desktop web app from ${source}`);
