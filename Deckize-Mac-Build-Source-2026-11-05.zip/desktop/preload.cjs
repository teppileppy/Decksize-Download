const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('deckizeDesktop', {
  isDesktop: true,
  getAppVersion: () => ipcRenderer.invoke('deckize:update:version'),
  getUpdateStatus: () => ipcRenderer.invoke('deckize:update:status'),
  checkForUpdates: () => ipcRenderer.invoke('deckize:update:check'),
  downloadUpdate: () => ipcRenderer.invoke('deckize:update:download'),
  installUpdate: () => ipcRenderer.invoke('deckize:update:install'),
  onUpdateStatus: callback => {
    if (typeof callback !== 'function') return () => {};
    const listener = (_event, status) => callback(status);
    ipcRenderer.on('deckize:update:status', listener);
    return () => ipcRenderer.removeListener('deckize:update:status', listener);
  }
});
