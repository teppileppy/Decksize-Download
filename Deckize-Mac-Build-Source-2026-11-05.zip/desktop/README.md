# Deckize desktop app

The Windows and macOS editions wrap the existing `../index.html` in a small Electron shell. The HTML remains the website/browser version and is copied into this project only when preparing a desktop build. The desktop Settings sheet uses a narrow preload bridge for app-version and update actions; Node access is not exposed to the page.

## Build installers locally

- Use Node.js 22.12 or newer.
- Windows: run `npm ci`, then `npm run build:win`.
- Linux: install Wine and the standard 64-bit Windows cross-build tools, then run `npm ci` and `npm run build:win`.
- macOS: run `npm ci`, then `npm run build:mac` on a Mac. It produces a universal DMG for Intel and Apple Silicon. The initial public build is unsigned/notarized, so macOS will show its normal unidentified-developer warning; users can Control-click the app and choose Open to allow it.

The free GitHub Actions workflow in `.github/workflows/build-macos.yml` builds the universal DMG on a GitHub-hosted macOS runner and attaches it to an existing public release. It requires the dated `Deckize-Mac-Build-Source-2026-11-05.zip` in the repository root and a workflow-dispatch input naming the release tag.

## Publish an updater-enabled release

A public GitHub repository is the update feed. The included root `.github/workflows/release.yml` builds/publishes the NSIS installer and electron-updater metadata when a GitHub Release is published. It derives the repository owner/name automatically, so there is no hard-coded account and no private token in the installed app. The workflow uses GitHub Actions' temporary token.

Publish the first release with tag `v1.1.0`; future tags such as `v1.1.1` set the app version for that build. The resulting installer checks only when the user presses **Settings → Desktop app → Check for updates**. The user confirms before download and again by choosing **Install and restart**. See `../GITHUB-UPDATE-SETUP.txt` for nontechnical publishing steps.

The app remains usable offline between checks. Deck data is stored in its own local app data, separate from browser storage; use Deckize's deck-file save/open actions to move presentations between browser and desktop storage. The installer remains unsigned, so Windows may show a SmartScreen/publisher warning. Update signature verification is disabled for the unsigned package; keep the GitHub release account secure.
